const Button = () => {
  return (
    <button className="h-12 rounded-lg bg-white font-bold px-5">Sign In</button>
  );
};

export default Button;
